# TODO-list
Mikhaylova Viktoriya

Todo list made using html, css, javascript
2022

Description of Todo -list application.

In the browser tab the name appears as "My to do list".  
A small text animation comes when the page is loaded.  When you hover over the Add button, it changes colour and size.

There is a text box (input field) in which you can enter an item. When you do this, one of three things will happen: 
-	The Item will be added to the list and notification is shown that item was added.
-	There will be an error message because the input is too short (equal or less than three characters), or the text box is empty. 
-	There will be another error message because the item is not unique (the item is already in the list).
 
You can mark the item completed or you can delete it. If you are using the same browser and the input value is stored in the browser’s local storage, if you want to redo the task you can uncheck it to make it active again. If you are using a different browser, you can not see your todo -list from other browser.

If you click the display button a menu pops up, the user can choose to display active items, all items or completed items. There is a counter on the bottom which shows the number of active items. 

Clicking on the date or location buttons triggers a popup with today’s date and your current location.

